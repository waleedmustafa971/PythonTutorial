# To execute a function, you call it by its name followed by parentheses.

def greet():
    print("Hello, Waleed!")


# To execute a function, you call it by its name followed by parentheses.


greet()  # Output: Hello, Waleed!
