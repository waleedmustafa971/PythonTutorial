# A function can return a value using the return statement. This allows you to capture the result of the function and use it elsewhere in your program.

def add(a, b):
    return a + b

result = add(3, 5)
print(result)  # Output: 8
