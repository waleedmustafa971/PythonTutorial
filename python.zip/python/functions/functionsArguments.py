# Functions can take inputs, called arguments, to perform operations with different data.
def greet(name):
    print(f"Hello, {name}!")

# Calling the function with an argument:

greet("Waleed")  # Output: Hello, Waleed!



