# You define a function using the def keyword, followed by the function name, parentheses, and a colon. The code inside the function is indented.
def greet():
    print("Hello, Waleed!")
