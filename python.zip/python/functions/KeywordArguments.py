def describe_person(name, age):
    print(f"{name} is {age} years old.")

describe_person(age=30, name="Waleed")  # Output: Waleed is 30 years old.
