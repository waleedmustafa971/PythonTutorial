# Integer
age = 30

# Float
height = 5.9

# String
name = "Waleed"

# Boolean
is_student = True

#printing

print(age)
