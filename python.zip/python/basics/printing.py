print("Hello, Waleed! Welcome to Python.")
