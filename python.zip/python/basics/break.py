for i in range(10):
    if i == 5:
        break  # Exit the loop when i equals 5
    print(i)

for i in range(10):
    if i % 2 == 0:
        continue  # Skip even numbers
    print(i)
