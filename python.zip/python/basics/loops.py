count = 1
while count <= 5:
    print("Count:", count)
    count += 1
#while count <= 5:: The loop will continue as long as count is less than or equal to 5.
#count += 1: This increases the value of count by 1 in each iteration to avoid an infinite loop.
