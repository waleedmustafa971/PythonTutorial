for i in range(5):
    print(i)


# You can customize the range with a start value and step size:

# for i in range(2, 10, 2):
#     print(i)
