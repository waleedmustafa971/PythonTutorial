a = 10
b = 5

sum_result = a + b
print("Sum:", sum_result)  # Output: Sum: 15

exp_result = a ** b
print("Exponentiation:", exp_result)  # Output: Exponentiation: 100000

multiple_result = a * b
print("Multiplication:", multiple_result)  # Output: Multiplication: 50

div_result = a/b
print("Division:", div_result)  # Output: Division: 2.0


